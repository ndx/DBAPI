
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<sys/types.h>
#include<unistd.h>
#include"Nikdb.h"

/*
 *global variables
 */
FILE *outfp;
unsigned int liberrno = 0;
#ifdef __MYSQL
char *data_type_str_tbl[DATA_TYPE_STR_TBL_LEN] = {
    str(TINYBLOB), str(TINYTEXT), str(BLOB), \
    str(TEXT), str(MEDIUMBLOB), str(MEDIUMTEXT), \
    str(LONGBLOB), str(LONGTEXT), str(DATE), \
    str(TIME), str(YEAR), str(DATETIME), \
    str(TIMESTAMP), str(DECIMAL), str(FLOAT), \
    str(DOUBLE), str(CHAR), str(VARCHAR), \
    str(NCHAR), str(NVARCHAR), str(BINARY), \
    str(VARBINARY), str(BIGINT), str(INT), \
    str(SMALLINT), str(TINYINT), str(BIT)
};
char *rstrict_tbl[RESTRICT_STR_TBL] = {
    "NOT NULL", "DEFAULT", "UNIQUE", \
    "CHECK", "PRIMARY KEY", "FORIGN KEY", \
    "AUTO_INCREMENT", "NULL"
};
char *query_condition_tbl[QUERY_CONDITION_LEN] = {\
    NULL, "=", ">", ">=", "<=", "<", "!=", \
    "LIKE", "NOT LIKE", "IS NULL", "IS NOT NULL"
};
#endif

/*
 *static function declarations
 */
static void libdb_print_error(DBDESC *desc, \
    const char *func, const char *info);
static unsigned int libdb_get_row_num(DBRES *result);
static unsigned int libdb_get_col_num(DBRES *result);
#ifdef __MYSQL
static int libdb_col2str(DBDESC *desc, \
DBCOLUME *col, char *col_str, int str_len);
static int libdb_type_atoi(char *type_str, int *type, int *size);
static unsigned int libdb_rstrict_atoi(const char *null, \
const char *key, const char *def, const char *extra);     /*maybe has some bugs*/
static unsigned int libdb_relocate(DBCOLUME **col_list);
static int libdb_get_next_pos(int lasttype, \
int thistype, int typelen, int cur_pos);
static void libdb_copy_data(DBCOLUME **col_list, \
DBROW row, void *buf, int nr_col, int nr_row, int unit_size);
static int libdb_get_where_statement(DBCOLUME *col, char *buf, int length);
static unsigned int libdb_get_row_where_statement(DBCOLUME **col_list, \
                            void *attr, void *buf, unsigned int length);
static unsigned int libdb_get_update_statement(DBCOLUME **col_list, \
                            void *attr, void *buf, unsigned int length);
static unsigned int libdb_get_insert_statement(DBCOLUME **col_list, \
			    void *attr, void *buf, unsigned int length);
#endif

void set_log_fp(FILE *fp)
{
    outfp = fp;
}

static void libdb_print_error(DBDESC *desc, \
    const char *func, const char *info)
{
    time_t tm = time(NULL);
    if( desc==NULL ) {
        fprintf(outfp, "%s %s(): %s.\n", ctime(&tm), func, info);
        return ;
    }
    errno_t err = libdb_get_errno(desc);
    if( err ) {
        liberrno = err;
        char str_time[32];
        memset(str_time, 0, sizeof(str_time));
        strcpy(str_time, ctime(&tm));
        str_time[strlen(str_time)-1] = 0;
        fprintf(outfp, "%s %s(): %s. %s\n", ctime(&tm), func, info, \
        libdb_strerror(desc));
    }
}

void *libdb_init(DBDESC *desc)
{
#ifdef __MYSQL
    return mysql_init(desc);
#endif
    return NULL;
}

/*
 * Return Value: NULL - failed. !NULL - Succeed.
 */
void *libdb_connect(void *param)
{
#ifdef __MYSQL
    if( param==NULL )
        return NULL;
    connect_t *mcp = (connect_t *)param;
    DBDESC *ret = mysql_real_connect(mcp->desc, \
           mcp->host, mcp->user, mcp->passwd, \
           mcp->db, mcp->port, mcp->unix_socket, \
           mcp->client_flag);
    if( ret==NULL ) {
        libdb_print_error(mcp->desc, "libdb_connect", \
        "connect database failed");
    }
    return ret;
#endif
    return NULL;
}

void libdb_close(DBDESC *desc)
{
#ifdef __MYSQL
    mysql_close(desc);
#endif
}

errno_t libdb_get_errno(DBDESC *desc)
{
#ifdef __MYSQL
    return mysql_errno(desc);
#endif
    return 0;
}

char *libdb_strerror(DBDESC *desc)
{
#ifdef __MYSQL
    return (char *)(mysql_error(desc));
#endif
    return NULL;
}

/*
 * Return Value: 0 - Succeed, -1 - failed.
 */
int libdb_shutdown(void *param)
{
#ifdef __MYSQL
    if( param==NULL )
        return -1;
    int ret;
    shutdown_t *msp = (shutdown_t *)param;
    ret = mysql_shutdown(msp->desc, msp->shutdown_level);
    if( ret ) {
        libdb_print_error(msp->desc, "libdb_shutdown", \
        "shutdown failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - failed. 0 - Succeed.
 */
int libdb_check_connection(DBDESC *desc)
{
    if( desc==NULL )
        return -1;
#ifdef __MYSQL
    int ret = mysql_ping(desc);
    if( ret ) {
        libdb_print_error(desc, "libdb_check_connection", \
        "Check connection failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - failed. 0 - Succeed.
 */
int libdb_set_default_db(DBDESC *desc, const char *db)
{
    if( desc==NULL || db==NULL )
        return -1;
#ifdef __MYSQL
    int ret = mysql_select_db(desc, db);
    if( ret ) {
        libdb_print_error(desc, "libdb_set_default_db", \
        "Set default database failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

char *libdb_get_dbserver_stat(DBDESC *desc)
{
    if( desc==NULL )
        return NULL;
#ifdef __MYSQL
    char *ret = (char *)mysql_stat(desc);
    if( ret==NULL ) {
        libdb_print_error(desc, "libdb_get_dbserver_stat", \
        "Get database status failed");
    }
    return ret;
#endif
    return NULL;
}

static unsigned int libdb_get_row_num(DBRES *result)
{
#ifdef __MYSQL
    return mysql_num_rows(result);
#endif
    return 0;
}

static unsigned int libdb_get_col_num(DBRES *result)
{
#ifdef __MYSQL
    return mysql_num_fields(result);
#endif
    return 0;
}

/*
 * Return Value: 0 - Failed or null. >0 - Succeed.
 */
unsigned int libdb_get_nr_row(DBDESC *desc, \
DBCOLUME *col, const char *tblname)
{
    if( desc==NULL || tblname==NULL || !strlen(tblname) )
        return 0;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), \
            "select * from %s ", tblname);
    if( col!=NULL ) {
        n += libdb_get_where_statement(col, query+n, sizeof(query)-n);
    }
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_get_nr_row", \
                          "Query failed");
        return 0;
    }
    DBRES *result;
    result = mysql_store_result(desc);
    if( result==NULL ) {
        libdb_print_error(desc, "libdb_get_nr_row", \
                              "Store result failed");
        return 0;
    }
    n = libdb_get_row_num(result);
    mysql_free_result(result);
    return n;
#endif
    return 0;
}

/*
 * Return value: -1 - failed. 0 - Succeed.
 */
int libdb_create_db(DBDESC *desc, const char *dbname)
{
    if( desc==NULL || dbname==NULL )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), \
                     "create database %s", \
                     dbname);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_create_db", \
                          "Create database failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

void libdb_clean_mem(char **list)
{
    if( list==NULL )
        return;
    char **fr = list;
    while( *fr!=NULL ) {
        free(*fr);
        fr++;
    }
    free(list);
}

/*
 * Return Value: NULL - failed. !NULL - Succeed.
 * It will return a pointer array which is end with a NULL.
 * After called this function, you need to call libdb_clean_mem()
 * to free these memory blocks.
 */
char **libdb_get_db_list(DBDESC *desc, int *num_row)
{
    if( desc==NULL )
        return NULL;
    char **list;
#ifdef __MYSQL
    char sql[] = "show databases";
    int ret, nr_col, nr_row;
    DBRES *result;
    DBROW row;
    ret = mysql_real_query(desc, sql, strlen(sql));
    if( ret ) {
        libdb_print_error(desc, "libdb_get_db_list", \
        "Get database list failed");
        return NULL;
    }
    result = mysql_store_result(desc);
    if( result==NULL ) {
        libdb_print_error(desc, "libdb_get_db_list", \
        "Store result failed");
        return NULL;
    }
    nr_col = libdb_get_col_num(result);
    if( nr_col!=1 ) {
        libdb_print_error(desc, "libdb_get_db_list", \
        "Too many columes");
        return NULL;
    }
    nr_row = libdb_get_row_num(result);
    if( num_row!=NULL )
        *num_row = nr_row;
    list = calloc(1, sizeof(char *)*(nr_row+1));
    if( list==NULL ) {
        libdb_print_error(NULL, "libdb_get_db_list", \
                          "POSITION 1. Allocate memory failed");
        return NULL;
    }
    int i = 0;
    while( (row = mysql_fetch_row(result)) ) {
        list[i] = calloc(1, MAX_DBNAME_LEN);
        if( list[i]==NULL ) {
            libdb_print_error(NULL, "libdb_get_db_list", \
                              "POSITION 2. Allocate memory failed");
            i--;
            do {
                free(list[i]);
            } while( i-- );
            free(list);
            return NULL;
        }
        strcpy(list[i++], row[0]);
    }
    list[i] = NULL;
    mysql_free_result(result);
    return list;
#endif
    return NULL;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_drop_db(DBDESC *desc, const char *dbname)
{
    if( desc==NULL || dbname==NULL )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, MAX_QUERY_LEN);
    int n = snprintf(query, sizeof(query), \
                     "drop database %s", \
                     dbname);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_drop_db", \
                          "Drop database failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value : -1 - failed. 0 - Succeed.
 */
int libdb_create_tbl(DBDESC *desc, \
const char *tblname, DBCOLUME *col_list, int nr_col)
{
    if( desc==NULL || tblname==NULL || col_list==NULL || nr_col<=0 )
        return -1;
#ifdef __MYSQL
    char prefix[] = "create table ";
    char tbl_chunk[2*MAX_TBL_LEN+1];
    char col[TRANS_COLUME_LEN];
    char query[MAX_QUERY_LEN];
    char *cur;
    memset(query, 0, sizeof(query));
    memset(tbl_chunk, 0, sizeof(tbl_chunk));
    int i, sum, n;
    sum = strlen(prefix);
    if( sum>=MAX_QUERY_LEN )
        return -1;
    strncpy(query, prefix, sum);
    cur = query + sum;
    n = mysql_real_escape_string(desc, tbl_chunk, tblname, strlen(tblname));
    if( !n )
        return -1;
    if( sum+n+1>=MAX_QUERY_LEN )
        return -1;
    memcpy(cur, tbl_chunk, n);
    cur += n;
    *cur++ = '(';
    sum += (n+1);
    for(i = 0; i<nr_col; i++) {
        memset(col, 0, sizeof(col));
        n = libdb_col2str(desc, &col_list[i], col, sizeof(col));
        if( n<0 )
            return -1;
        if( n+sum>=MAX_QUERY_LEN )
            return -1;
        memcpy(cur, col, n);
        sum += n;
        cur += n;
    }
    /*clean final comma*/
    *(--cur) = 0;
    sum--;

    if( sum+2>=MAX_QUERY_LEN )
        return -1;
    *cur++ = ')';
    *cur = 0;
    sum++;
    int ret = mysql_real_query(desc, query, sum);
    if( ret ) {
        libdb_print_error(desc, "libdb_create_tbl", \
        "Create table failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

#ifdef __MYSQL
/*
 * Return Value: -1 - failed. 0 - Succeed.
 */
static int libdb_col2str(DBDESC *desc, \
DBCOLUME *col, char *col_str, int str_len)
{
    if( desc==NULL || col==NULL || col_str==NULL || str_len<=0 )
        return -1;
    char chunk[2*MAX_COLUME_LEN+1];
    memset(chunk, 0, sizeof(chunk));
    int sum = 0;
    char *cur = col_str;
    /*colume name*/
    int n = mysql_real_escape_string(desc, chunk, col->col_name, strlen(col->col_name));
    if( !n )
        return -1;
    sum += n;
    if( sum+1>str_len )
        return -1;
    memcpy(col_str, chunk, sum);
    cur += sum;
    *cur++ = ' ';
    sum++;
    /*type*/
    if( col->col_type<0 || col->col_type>DATA_TYPE_STR_TBL_LEN )
        return -1;
    n = strlen(data_type_str_tbl[col->col_type]);
    if( sum+n+1>str_len )
        return -1;
    strncpy(cur, data_type_str_tbl[col->col_type], n);
    cur += n;
    sum += n;
    if( isNeedSize(col->col_type) ) {
        char data_size[MAX_DATA_SIZE_LEN];
        memset(data_size, 0, sizeof(data_size));
        sprintf(data_size, "%d", col->col_type_len);
        n = strlen(data_size);
        if( sum+n+2>str_len )
            return -1;
        *cur++ = '(';
        strncpy(cur, data_size, n);
        cur += n;
        *cur++ = ')';
        sum += (n+2);
    } else if( isAccuracy(col->col_type) ) {
        char data_size[MAX_DATA_SIZE_LEN];
        memset(data_size, 0, sizeof(data_size));
        int n;
        if( col->col_type==FLOAT ) {
            n = snprintf(data_size, sizeof(data_size), \
                         "(%d,%d)", col->col_type_len, FLOATACC);
        } else if( col->col_type==DOUBLE ) {
            n = snprintf(data_size, sizeof(data_size), \
                         "(%d,%d)", col->col_type_len, DOUBLEACC);
        } else {
            libdb_print_error(NULL, "libdb_col2str", \
                              "No such type");
            exit(1);
        }
        strncpy(cur, data_size, n);
        cur += n;
        sum += n;
    }
    *cur++ = ' ';
    sum++;
    /*restrict*/
    if( col->rstrict<0 || col->rstrict>rStrict(RESTRICT_STR_TBL) )
        return -1;
    int i;
    for(i = 0; i<RESTRICT_STR_TBL; i++) {
        if( (col->rstrict)&rStrict(i) ) {
            n = strlen(rstrict_tbl[i]);
            if( sum+n+1>str_len )
                return -1;
            strncpy(cur, rstrict_tbl[i], n);
            cur += n;
            *cur++ = ' ';
            sum += (n+1);
        }
    }
    if( sum+2>str_len )
        return -1;
    *cur++ = ',';
    sum++;
    *cur = 0;
    return sum;
}
#endif

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_drop_tbl(DBDESC *desc, const char *tblname)
{
    if( desc==NULL || tblname==NULL || !strlen(tblname) )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), \
                     "drop table %s", \
                     tblname);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_drop_tbl", \
                          "Drop table failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_add_col(DBDESC *desc, const char *tblname, DBCOLUME *col)
{
    if( desc==NULL || col==NULL || !strlen(tblname) )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    char tbl_chunk[MAX_TBL_LEN*2+1];
    char col_chunk[TRANS_COLUME_LEN];
    int sum = 0, n;
    char sql[] = "alter table ";
    char *cur = query;
    memset(query, 0, sizeof(query));
    memset(tbl_chunk, 0, sizeof(tbl_chunk));
    memset(col_chunk, 0, sizeof(col_chunk));
    sum += strlen(sql);
    if( sum>=MAX_QUERY_LEN )
        return -1;
    strncpy(query, sql, sum);
    cur += sum;
    n = mysql_real_escape_string(desc, tbl_chunk, tblname, strlen(tblname));
    if( !n )
        return -1;
    if( sum+n+5>=MAX_QUERY_LEN )
        return -1;
    memcpy(cur, tbl_chunk, n);
    cur += n;
    strncpy(cur, " add ", 5);
    cur += 5;
    sum += (n+5);
    n = libdb_col2str(desc, col, col_chunk, sizeof(col_chunk));
    if( n<0 )
        return -1;
    if( n+sum>=MAX_QUERY_LEN )
        return -1;
    memcpy(cur, col_chunk, n);
    sum += n;
    cur += n;
    *(--cur) = 0;
    sum--;
    n = mysql_real_query(desc, query, sum);
    if( n ) {
        libdb_print_error(desc, "libdb_add_col", \
        "Add colume failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_del_col(DBDESC *desc, \
const char *tblname, const char *colname)
{
    if( desc==NULL || tblname==NULL || \
        !strlen(tblname) || colname==NULL || \
        !strlen(colname) )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, MAX_QUERY_LEN, \
                "alter table %s drop %s", \
                tblname, colname);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_del_col", \
                         "Delete colume failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value 
 */
DBCOLUME **libdb_get_col_info(DBDESC *desc, const char *tblname)
{
    if( desc==NULL || tblname==NULL || !strlen(tblname) )
        return NULL;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), \
                     "desc %s", tblname);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_get_col_info", \
                          "Get colume type failed");
        return NULL;
    }
    DBRES *result = mysql_store_result(desc);
    if( result==NULL ) {
        libdb_print_error(desc, "libdb_get_col_info", \
                          "Store result failed");
        return NULL;
    }
    n = libdb_get_row_num(result);
    DBCOLUME **col_list = calloc(1, sizeof(DBCOLUME *)*(n+1));
    if( col_list==NULL ) {
        libdb_print_error(NULL, "libdb_get_col_info", \
                          "POSITION 1. Allocate memory failed");
        return NULL;
    }
    n = libdb_get_col_num(result);
    if( n!=6 ) {  /*desc tablename only has 6 colume in mysql*/
        free(col_list);
        return NULL;
    }
    DBROW row;
    int i = 0;
    while( (row = mysql_fetch_row(result)) ) {
        col_list[i] = calloc(1, sizeof(DBCOLUME));
        if( col_list[i]==NULL ) {
            libdb_print_error(NULL, "libdb_get_col_info", \
                              "POSITION 2. Allocate memory failed");
            i--;
err:        do {
                free(col_list[i]);
            } while( i-- );
            free(col_list);
            return NULL;
        }
        strcpy(col_list[i]->col_name, row[0]);
        ret = libdb_type_atoi(row[1], \
              &(col_list[i]->col_type), \
              &(col_list[i]->col_type_len));
        if( ret<0 ) {
            goto err;
        }
        col_list[i]->rstrict = libdb_rstrict_atoi(row[2], row[3], row[4], row[5]);
        i++;
    }
    col_list[i] = NULL;
    mysql_free_result(result);
    return col_list;
#endif
    return NULL;
}

#ifdef __MYSQL
/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
static int libdb_type_atoi(char *type_str, int *type, int *size)
{
    if( type_str==NULL || type==NULL )
        return -1;
    char *p = type_str;
    int cnt = 0;
    for(; *p!='(' && *p!=0; p++, cnt++)
        ;
    int i;
    for(i = 0; i<DATA_TYPE_STR_TBL_LEN; i++) {
        if( !strncasecmp(type_str, data_type_str_tbl[i], cnt) )
            break;
    }
    if( i>=DATA_TYPE_STR_TBL_LEN )
        return -1;
    *type = i;
    if( *p=='(' && isNeedSize(i) && size!=NULL ) {
        char *q = ++p;
        for(; *q!=')' && *q!=0; q++)
            ;
        if( !(*q) )
            return -1;
        *q = 0;
        *size = atoi(p);
    } else if( *p=='(' && isAccuracy(i) && size!=NULL ) {
        char *q = ++p;
        for(; *q!=',' && *q!=0; q++)
            ;
        if( !(*q) )
            return -1;
        *q = 0;
        *size = atoi(p);
    }
    return 0;
}

/*
 * Return Value: No Failed.
 */
static unsigned int libdb_rstrict_atoi(const char *null, \
const char *key, const char *def, const char *extra)
{
    unsigned int ret = 0;
    if( null!=NULL ) {
        if( !strcasecmp(null, "YES") )
            ret |= rStrict(Null);
        else
            ret |= rStrict(NOTNULL);
    }
    if( key!=NULL && !strcasecmp(key, "PRI") )
        ret |= rStrict(PRIMARYKEY);
    if( def!=NULL && strcasecmp(def, "NULL") && def[0]!=0 )
        ret |= rStrict(DEFAULT);
    if( extra!=NULL ) {
        if( !strcasecmp(extra, "auto_increment") )
            ret |= rStrict(AUTOINCREMENT);
    }
    return ret;
}
#endif

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_add_primary_key(DBDESC *desc, \
const char *tbl_name, const char *col_name)
{
    if( desc==NULL || \
        tbl_name==NULL || !strlen(tbl_name) || \
        col_name==NULL || !strlen(col_name) )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), \
            "alter table %s add primary key(%s)", \
            tbl_name, col_name);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_add_primary_key", \
                          "Add primary key failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_del_primary_key(DBDESC *desc, const char *tbl_name)
{
    if( desc==NULL || \
        tbl_name==NULL || !strlen(tbl_name) )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), \
            "alter table %s drop primary key", \
            tbl_name);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_del_primary_key", \
                          "Delete primary key failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_chg_tbl_name(DBDESC *desc, \
const char *oldname, const char *newname)
{
    if( desc==NULL || \
        oldname==NULL || !strlen(oldname) || \
        newname==NULL || !strlen(newname) )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), \
            "alter table %s rename to %s", \
            oldname, newname);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_chg_tbl_name", \
                          "Change table name failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_mod_col_info(DBDESC *desc, \
const char *tblname, DBCOLUME *oldcol, DBCOLUME *newcol)
{
    if( desc==NULL || oldcol==NULL || newcol==NULL )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    char chunk[TRANS_COLUME_LEN];
    memset(chunk, 0, sizeof(chunk));
    memset(query, 0, sizeof(query));
    int n = libdb_col2str(desc, newcol, chunk, sizeof(chunk));
    if( n<0 )
        return -1;
    chunk[n-1] = 0;
    n = snprintf(query, sizeof(query), \
            "alter table %s change %s %s", \
            tblname, oldcol->col_name, chunk);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_mod_col_info", \
                          "Modify colume information failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_read_reg_tbl(DBDESC *desc, const char *tblname, \
            DBCOLUME *col, void *buf, unsigned int length)
{
    if( desc==NULL || tblname==NULL || \
        buf==NULL || !length )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), \
            "select * from %s ", tblname);
    if( col!=NULL )
        n += libdb_get_where_statement(col, query+n, sizeof(query)-n);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_read_reg_tbl", \
                          "Read regular table failed");
        return -1;
    }
    DBRES *result = mysql_store_result(desc);
    if( result==NULL ) {
        libdb_print_error(desc, "libdb_read_reg_tbl", \
                          "Store result failed");
        return -1;
    }
    n = libdb_get_row_num(result);
    DBCOLUME **col_list = libdb_get_col_info(desc, tblname);
    if( col_list==NULL ) {
        return -1;
    }
    int size = libdb_relocate(col_list);
    if( size<0 ) {
        libdb_print_error(NULL, "libdb_read_reg_tbl", \
                          "Relocate error");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    if( size*n>length ) {
        libdb_print_error(NULL, "libdb_read_reg_tbl", \
                          "Buffer length is not enough");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    n = libdb_get_col_num(result);
    DBROW row;
    int nr_row = 0;
    while( (row = mysql_fetch_row(result)) ) {
        libdb_copy_data(col_list, row, buf, n, nr_row, size);
        nr_row++;
    }
    libdb_clean_mem((char **)col_list);
    mysql_free_result(result);
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_read_reg_row(DBDESC *desc, const char *tblname, \
                void *attr, void *buf, unsigned int length)
{
    if( desc==NULL || tblname==NULL || !strlen(tblname) || \
        attr==NULL || buf==NULL || !length )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), \
            "select * from %s ", tblname);
    DBCOLUME **col_list = libdb_get_col_info(desc, tblname);
    if( col_list==NULL ) {
        return -1;
    }
    int size = libdb_relocate(col_list);
    if( size<0 ) {
        libdb_print_error(NULL, "libdb_read_reg_row", \
                          "Relocate error");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    if( size>length ) {
        libdb_print_error(NULL, "libdb_read_reg_row", \
                          "Buffer length is not enough");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    n += libdb_get_row_where_statement(col_list, \
                    attr, query+n, sizeof(query)-n);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_read_reg_row", \
                          "Select failed");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    DBRES *result = mysql_store_result(desc);
    if( result==NULL ) {
        libdb_print_error(desc, "libdb_read_reg_row", \
                              "Store result failed");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    n = libdb_get_row_num(result);
    if( n!=1 ) {
        if( !n )
            libdb_print_error(NULL, "libdb_read_reg_row", \
                              "Result is empty");
        else
            libdb_print_error(NULL, "libdb_read_reg_row", \
                              "Result is not only one row");
        mysql_free_result(result);
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    n = libdb_get_col_num(result);
    DBROW row;
    int nr_row = 0;
    while( (row = mysql_fetch_row(result)) ) {
        libdb_copy_data(col_list, row, buf, n, nr_row, size);
        nr_row++;
    }
    libdb_clean_mem((char **)col_list);
    mysql_free_result(result);
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_del_reg_tbl(DBDESC *desc, const char *tblname, DBCOLUME *col)
{
    if( desc==NULL || tblname==NULL || !strlen(tblname) )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), "delete from %s ", tblname);
    if( col!=NULL )
        n += libdb_get_where_statement(col, query+n, sizeof(query)-n);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_del_reg_tbl", \
                          "Delete columes failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_del_reg_row(DBDESC *desc, const char *tblname, void *attr)
{
    if( desc==NULL || tblname==NULL || \
        !strlen(tblname) || attr==NULL )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n =snprintf(query, sizeof(query), "delete from %s ", tblname);
    DBCOLUME **col_list = libdb_get_col_info(desc, tblname);
    if( col_list==NULL ) {
        return -1;
    }
    int size = libdb_relocate(col_list);
    if( size<0 ) {
        libdb_print_error(NULL, "libdb_del_reg_row", "Relocate error");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    n += libdb_get_row_where_statement(col_list, \
                    attr, query+n, sizeof(query)-n);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_del_reg_row", "Delete failed");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    libdb_clean_mem((char **)col_list);
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_update_reg_row(DBDESC *desc, const char *tblname, void *attr, void *val)
{
    if( desc==NULL || tblname==NULL || \
        !strlen(tblname) || attr==NULL || val==NULL )
        return -1;
#ifdef __MYSQL
    DBCOLUME **list_attr, **list_val;
    list_attr = libdb_get_col_info(desc, tblname);
    if( list_attr==NULL ) {
        return -1;
    }
    list_val = libdb_get_col_info(desc, tblname);
    if( list_val==NULL ) {
        libdb_clean_mem((char **)list_attr);
        return -1;
    }
    int size = libdb_relocate(list_attr);
    if( size<0 ) {
        libdb_print_error(NULL, "libdb_updata_reg_row", "Relocate attr error");
        libdb_clean_mem((char **)list_attr);
        libdb_clean_mem((char **)list_val);
        return -1;
    }
    size = libdb_relocate(list_val);
    if( size<0 ) {
        libdb_print_error(NULL, "libdb_update_reg_row", "Relocate value error");
        libdb_clean_mem((char **)list_attr);
        libdb_clean_mem((char **)list_val);
        return -1;
    }
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), "UPDATE %s SET ", tblname);
    n += libdb_get_update_statement(list_val, val, query+n, sizeof(query)-n);
    char *drop_comma = query + n - 1;
    for(; *drop_comma!=',' && drop_comma!=query; drop_comma--, n--)
        ;
    *drop_comma = ' ';
    n += libdb_get_row_where_statement(list_attr, attr, query+n, sizeof(query)-n);
    libdb_clean_mem((char **)list_attr);
    libdb_clean_mem((char **)list_val);
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_update_reg_row", "Update failed");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/*
 * Return Value: -1 - Failed. 0 - Succeed.
 */
int libdb_insert_reg_row(DBDESC *desc, \
const char *tblname, void *attr, unsigned int length)
{
    if( desc==NULL || attr==NULL || \
        tblname==NULL || !strlen(tblname) || \
        !length )
        return -1;
#ifdef __MYSQL
    char query[MAX_QUERY_LEN];
    memset(query, 0, sizeof(query));
    int n = snprintf(query, sizeof(query), "INSERT INTO %s(", tblname);
    DBCOLUME **col_list = libdb_get_col_info(desc, tblname);
    if( col_list==NULL ) {
        return -1;
    }
    int size = libdb_relocate(col_list);
    if( size<0 ) {
        libdb_print_error(NULL, \
        "libdb_insert_reg_row", "Relocate attr error");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    if( size!=length ) {
        libdb_print_error(NULL, "libdb_insert_reg_row", \
                 "size of attr and length are not match");
        libdb_clean_mem((char **)col_list);
        return -1;
    }
    DBCOLUME **scan = col_list;
    while( *scan!=NULL ) {
        n += snprintf(query + n, sizeof(query)-n, "%s, ", (*scan)->col_name);
        scan++;
    }
    char *p = query + n - 1;
    for(; *p!=',' && p!=query; p--, n--) {
        *p = 0;
    }
    *p = 0;
    n--;
    n += snprintf(query + n, sizeof(query)-n, ")VALUES(");
    n += libdb_get_insert_statement(col_list, attr, query+n, sizeof(query)-n);
    libdb_clean_mem((char **)col_list);
    p = query + n - 1;
    for(; *p!=',' && p!=query; p--, n--) {
        *p = 0;
    }
    *p = ')';
    int ret = mysql_real_query(desc, query, n);
    if( ret ) {
        libdb_print_error(desc, "libdb_insert_reg_row", \
                                "INSERT ONE ROW FAILED");
        return -1;
    }
    return 0;
#endif
    return -1;
}

/////////////////////////////////////////////////////////////////////////////////////////////?
#ifdef __MYSQL
static void libdb_copy_data(DBCOLUME **col_list, \
DBROW row, void *buf, int nr_col, int nr_row, int unit_size)
{
    int i, base = nr_row*unit_size;
    char *start;
    for(i = 0; i<nr_col; i++) {
        start = (char *)buf + base + col_list[i]->start_pos;
        switch( col_list[i]->col_type ) {
            case FLOAT:
            {
                float n = (float)atof(row[i]);
                *(float *)start = n;
                break;
            }
            case INT:
            {
                int n = atoi(row[i]);
                *(int *)start = n;
                break;
            }
            case DOUBLE:
            {
                double n = (double)atof(row[i]);
                *(double *)start = n;
                break;
            }
            case BIGINT:
            {
                bigint n = atoll(row[i]);
                *(bigint *)start = n;
                break;
            }
            case CHAR:
            case VARCHAR:
            case NVARCHAR:
            {
                memcpy(start, row[i], col_list[i]->col_type_len);
                break;
            }
            case TINYINT:
            {
                unsigned char n = (unsigned char)atoi(row[i]);
                *(unsigned char *)start = n;
                break;
            }
            case SMALLINT:
            {
                short n = (short)atoi(row[i]);
                *(short *)start = n;
                break;
            }
            default:
                libdb_print_error(NULL, "libdb_copy_data", \
                                  "No such type");
                exit(1);
        }
    }
}

/*
 * Return Value: 0 - Failed. >0 Succeed.
 */
static unsigned int libdb_relocate(DBCOLUME **col_list)
{
    DBCOLUME **scan = col_list;
    int type = -1, cur_pos = 0, len = 0;
    while( *scan!=NULL ) {
        if( type==-1 ) {
            (*scan)->start_pos = cur_pos;
            type = (*scan)->col_type;
            len = (*scan)->col_type_len;
            scan++;
            continue;
        } else {
            cur_pos = libdb_get_next_pos(type, \
                      (*scan)->col_type, len, cur_pos);
            (*scan)->start_pos = cur_pos;
            type = (*scan)->col_type;
            len = (*scan)->col_type_len;
        }
        if( cur_pos<0 ) {
            libdb_print_error(NULL, "libdb_relocate", \
                             "Get position failed");
            return 0;
        }
        scan++;
    }
    if( col_list!=scan ) {
        cur_pos = libdb_get_next_pos(type, \
                  BIGINT, len, cur_pos);
        return cur_pos;
    }
    return 0;
}

/*
 * Return Value: -1 = Failed. >=0 - Succeed.
 */
#ifdef __x86_64
static int libdb_get_next_pos(int lasttype, \
int thistype, int typelen, int cur_pos)
{
    switch( lasttype ) {
        case -1:
            return 0;
            break;
        case INT:
        case FLOAT:
        {
            if( thistype==BIGINT || thistype==DOUBLE ) {
                goto four;
            } else if( thistype==SMALLINT || thistype==INT || \
                       thistype==FLOAT || thistype==CHAR || \
                       thistype==VARCHAR || thistype==NVARCHAR || \
                       thistype==TINYINT )
            {
four:           cur_pos += typelen;
                int n = cur_pos % 4;
                if( n )
                    cur_pos += (4 - n);
                return cur_pos;
            } else {
                return -1;
            }
        }
        case SMALLINT:
        {
            if( thistype==BIGINT || thistype==DOUBLE ) {
eight:          cur_pos += typelen;
                int n = cur_pos % 8;
                if( n )
                    cur_pos += (8 - n);
                return cur_pos;
            } else if( thistype==INT || thistype==FLOAT ) {
                goto four;
            } else if( thistype==CHAR || thistype==VARCHAR || \
                       thistype==NVARCHAR || thistype==TINYINT )
            {
two:            cur_pos += typelen;
                int n = cur_pos % 2;
                if( n )
                    cur_pos += (2 - n);
                return cur_pos;
            } else {
                return -1;
            }
        }
        case BIGINT:
        case DOUBLE:
        {
            if( thistype==BIGINT || thistype==DOUBLE || \
                thistype==INT || thistype==FLOAT || \
                thistype==CHAR || thistype==VARCHAR || \
                thistype==NVARCHAR || thistype==TINYINT )
            {
                goto eight;
            } else {
                return -1;
            }
        }
        case CHAR:
        case VARCHAR:
        case NVARCHAR:
        case TINYINT:
        {
            if( thistype==BIGINT || thistype==DOUBLE )
                goto eight;
            else if( thistype==INT || thistype==FLOAT )
                goto four;
            else if( thistype==SMALLINT )
                goto two;
            else if( thistype==CHAR || thistype==VARCHAR || \
                     thistype==NVARCHAR || thistype==TINYINT )
            {
                return cur_pos+typelen;
            }
        }
        default:
            return -1;
    }
    return -1;
}
        
#else
static int libdb_get_next_pos(int lasttype, \
int thistype, int typelen, int cur_pos)
{
    switch( lasttype ) {
        case -1:
            return 0;
            break;
        case INT:
        case BIGINT:
        case FLOAT:
        {
four:       cur_pos += typelen;
            int n = cur_pos % 4;
            if( n ) {
                cur_pos += (4 - n);
            }
            return cur_pos;
        }
        case DOUBLE:
        {
            cur_pos += typelen;
            int n = cur_pos % 4;
            if( n )
                cur_pos += (8 - n);
            return cur_pos;
        }
        case CHAR:
        case VARCHAR:
        case NVARCHAR:
        case TINYINT:
        {
            if( thistype==INT || thistype==BIGINT || \
                thistype==FLOAT || thistype==DOUBLE )
            {
                goto four;
            } else if( thistype==CHAR|| thistype==VARCHAR || \
                       thistype==NVARCHAR || thistype==TINYINT )
            {
                return cur_pos+typelen;
            } else if( thistype==SMALLINT ) {
two:            cur_pos += typelen;
                int n = cur_pos%2;
                if( n )
                    cur_pos += (2 - n);
                return cur_pos;
            } else {
                return -1;
            }
        }
        case SMALLINT:
        {
            if( thistype==CHAR || thistype==VARCHAR || \
                thistype==NVARCHAR || thistype==SMALLINT || \
                thistype==TINYINT )
            {
                goto two;
            } else if( thistype==INT || thistype==BIGINT || \
                       thistype==FLOAT || thistype==DOUBLE )
            {
                goto four;
            } else {
                return -1;
            }
        }
        default:
            return -1;
    }
    return -1;
}
#endif

/*
 * Return Value: -1 - Failed. >=0 - writen characters in buf.
 */
static int libdb_get_where_statement(DBCOLUME *col, char *buf, int length)
{
    if( col==NULL || buf==NULL || !length )
        return -1;
    if( !col->query_cond )
        return 0;
    if( col->query_cond>=QUERY_CONDITION_LEN )
        return -1;
    char val_str[MAX_OTHER_LEN];
    memset(val_str, 0, sizeof(val_str));
    switch( col->col_type ) {
        case FLOAT:
            snprintf(val_str, sizeof(val_str), "%f", col->val.fval);
            break;
        case DOUBLE:
            snprintf(val_str, sizeof(val_str), "%lf", col->val.dval);
            break;
        case CHAR:
        case VARCHAR:
        case NVARCHAR:
            if( col->col_type_len==sizeof(char) )
                snprintf(val_str, sizeof(val_str), "%c", col->val.cval);
            break;
        case BIGINT:
        #ifdef __x86_64
            snprintf(val_str, sizeof(val_str), "%ld", col->val.bval);
        #else
            snprintf(val_str, sizeof(val_str), "%lld", col->val.bval);
        #endif
            break;
        case INT:
            snprintf(val_str, sizeof(val_str), "%d", col->val.ival);
            break;
        case SMALLINT:
            snprintf(val_str, sizeof(val_str), "%d", col->val.sval);
            break;
        case TINYINT:
            snprintf(val_str, sizeof(val_str), "%d", col->val.tval);
            break;
        default:
            return -1;
    }
    int n = snprintf(buf, length, "where %s %s %s", \
            col->col_name, query_condition_tbl[col->query_cond], \
            val_str);
    return n;
}

/*
 * Return Value: 0 - Failed or null. >0 - Number of writen characters.
 */
static unsigned int libdb_get_row_where_statement(DBCOLUME **col_list, \
                            void *attr, void *buf, unsigned int length)
{
    if( col_list==NULL || attr==NULL || buf==NULL || !length )
        return 0;
    unsigned int sum = 0, n;
    int where_mark = 0;
    DBCOLUME **scan = col_list;
    while( *scan!=NULL ) {
        switch( (*scan)->col_type ) {
            case FLOAT:
                (*scan)->val.fval = *(float *)(attr + (*scan)->start_pos);
                if( (*scan)->val.fval==IGNORED )
                    break;
                if( !where_mark ) {
                    n = snprintf(buf, length, "where %s=%f ", \
                                   (*scan)->col_name, (*scan)->val.fval);
                    where_mark = 1;
                    goto out;
                } else {
                    n = snprintf(buf, length, "AND %s=%f ", \
                                   (*scan)->col_name, (*scan)->val.fval);
out:                sum += n;
                    length -= n;
                    buf += n;
                }
                break;
            case DOUBLE:
                (*scan)->val.dval = *(double *)(attr + (*scan)->start_pos);
                if( (*scan)->val.dval==IGNORED )
                    break;
                if( !where_mark ) {
                    n = snprintf(buf, length, "where %s=%lf ", \
                                   (*scan)->col_name, (*scan)->val.dval);
                    where_mark = 1;
                    goto out;
                } else {
                    n = snprintf(buf, length, "AND %s=%lf ", \
                                   (*scan)->col_name, (*scan)->val.dval);
                    goto out;
                }
                break;
            case CHAR:
            case VARCHAR:
            case NVARCHAR:
            {
                unsigned int len = (*scan)->col_type_len;
                if( len==1 ) {
                    (*scan)->val.cval = *(char *)(attr + (*scan)->start_pos);
                    if( (*scan)->val.cval==IGNORED )
                        break;
                }
                else {
                    (*scan)->val.buf = (char *)(attr + (*scan)->start_pos);
                    if( (*scan)->val.buf==NULL || !strlen((*scan)->val.buf) )
                        break;
                }
                if( !where_mark ) {
                    if( len==1 ) {
                        n = snprintf(buf, length, "where %s='%c' ", \
                                   (*scan)->col_name, (*scan)->val.cval);
                    } else {
                        n = snprintf(buf, length, "where %s='%s' ", \
                                   (*scan)->col_name, (char *)((*scan)->val.buf));
                    }
                    where_mark = 1;
                    goto out;
                } else {
                    if( len==1 )
                        n = snprintf(buf, length, "AND %s='%c' ", \
                                   (*scan)->col_name, (*scan)->val.cval);
                    else
                        n = snprintf(buf, length, "AND %s='%s' ", \
                                   (*scan)->col_name, (char *)((*scan)->val.buf));
                    goto out;
                }
                break;
            }
            case BIGINT:
                (*scan)->val.bval = *(bigint *)(attr + (*scan)->start_pos);
                if( (*scan)->val.bval==IGNORED )
                    break;
                if( !where_mark ) {
                #ifdef __x86_64
                    n = snprintf(buf, length, "where %s=%ld ", \
                                   (*scan)->col_name, (*scan)->val.bval);
                #else
                    n = snprintf(buf, length, "where %s=%lld ", \
                                   (*scan)->col_name, (*scan)->val.bval);
                #endif
                    where_mark = 1;
                    goto out;
                } else {
                #ifdef __x86_64
                    n = snprintf(buf, length, "AND %s=%ld ", \
                                   (*scan)->col_name, (*scan)->val.bval);
                #else
                    n = snprintf(buf, length, "AND %s=%lld ", \
                                   (*scan)->col_name, (*scan)->val.bval);
                #endif
                    goto out;
                }
                break;
            case INT:
                (*scan)->val.ival = *(int *)(attr + (*scan)->start_pos);
                if( (*scan)->val.ival==IGNORED )
                    break;
                if( !where_mark ) {
                    n = snprintf(buf, length, "where %s=%d ", \
                                   (*scan)->col_name, (*scan)->val.ival);
                    where_mark = 1;
                    goto out;
                } else {
                    n = snprintf(buf, length, "AND %s=%d ", \
                                   (*scan)->col_name, (*scan)->val.ival);
                    goto out;
                }
                break;
            case SMALLINT:
                (*scan)->val.sval = *(short *)(attr + (*scan)->start_pos);
                if( (*scan)->val.sval==IGNORED )
                    break;
                if( !where_mark ) {
                    n = snprintf(buf, length, "where %s=%d ", \
                                   (*scan)->col_name, (*scan)->val.sval);
                    where_mark = 1;
                    goto out;
                } else {
                    n = snprintf(buf, length, "AND %s=%d ", \
                                   (*scan)->col_name, (*scan)->val.sval);
                    goto out;
                }
                break;
            case TINYINT:
                (*scan)->val.sval = *(tinyint *)(attr + (*scan)->start_pos);
                if( (*scan)->val.tval==(tinyint)IGNORED )
                    break;
                if( !where_mark ) {
                    n = snprintf(buf, length, "where %s=%d ", \
                                   (*scan)->col_name, (*scan)->val.tval);
                    where_mark = 1;
                    goto out;
                } else {
                    n = snprintf(buf, length, "AND %s=%d ", \
                                   (*scan)->col_name, (*scan)->val.tval);
                    goto out;
                }
                break;
            default:
                return 0;
        }
        scan++;
    }
    return sum;
}

/*
 * Return Value: 0 - Failed or null. >0 - Number of writen characters.
 */
static unsigned int libdb_get_update_statement(DBCOLUME **col_list, \
                            void *attr, void *buf, unsigned int length)
{
    if( col_list==NULL || attr==NULL || buf==NULL || !length )
        return 0;
    unsigned int sum = 0, n;
    DBCOLUME **scan = col_list;
    while( *scan!=NULL ) {
        switch( (*scan)->col_type ) {
            case FLOAT:
                (*scan)->val.fval = *(float *)(attr + (*scan)->start_pos);
                if( (*scan)->val.fval==IGNORED )
                    break;
                n = snprintf(buf, length, "%s=%f, ", \
                    (*scan)->col_name, (*scan)->val.fval);
out:            sum += n;
                length -= n;
                buf += n;
                break;
            case DOUBLE:
                (*scan)->val.dval = *(double *)(attr + (*scan)->start_pos);
                if( (*scan)->val.dval==IGNORED )
                    break;
                n = snprintf(buf, length, "%s=%lf, ", \
                    (*scan)->col_name, (*scan)->val.dval);
                goto out;
                break;
            case CHAR:
            case VARCHAR:
            case NVARCHAR:
            {
                unsigned int len = (*scan)->col_type_len;
                if( len==1 ) {
                    (*scan)->val.cval = *(char *)(attr + (*scan)->start_pos);
                    if( (*scan)->val.cval==IGNORED )
                        break;
                }
                else {
                    (*scan)->val.buf = (char *)(attr + (*scan)->start_pos);
                    if( (*scan)->val.buf==NULL || !strlen((*scan)->val.buf) )
                        break;
                }
                if( len==1 )
                    n = snprintf(buf, length, "%s='%c', ", \
                               (*scan)->col_name, (*scan)->val.cval);
                else
                    n = snprintf(buf, length, "%s='%s', ", \
                               (*scan)->col_name, (char *)((*scan)->val.buf));
                goto out;
                break;
            }
            case BIGINT:
                (*scan)->val.bval = *(bigint *)(attr + (*scan)->start_pos);
                if( (*scan)->val.bval==IGNORED )
                    break;
            #ifdef __x86_64
                n = snprintf(buf, length, "%s=%ld, ", \
                               (*scan)->col_name, (*scan)->val.bval);
            #else
                n = snprintf(buf, length, "%s=%lld, ", \
                               (*scan)->col_name, (*scan)->val.bval);
            #endif
                goto out;
                break;
            case INT:
                (*scan)->val.ival = *(int *)(attr + (*scan)->start_pos);
                if( (*scan)->val.ival==IGNORED )
                    break;
                n = snprintf(buf, length, "%s=%d, ", \
                              (*scan)->col_name, (*scan)->val.ival);
                goto out;
                break;
            case SMALLINT:
                (*scan)->val.sval = *(short *)(attr + (*scan)->start_pos);
                if( (*scan)->val.sval==IGNORED )
                    break;
                n = snprintf(buf, length, "%s=%d, ", \
                              (*scan)->col_name, (*scan)->val.sval);
                goto out;
                break;
            case TINYINT:
                (*scan)->val.sval = *(tinyint *)(attr + (*scan)->start_pos);
                if( (*scan)->val.tval==(tinyint)IGNORED )
                    break;
                n = snprintf(buf, length, "%s=%d, ", \
                              (*scan)->col_name, (*scan)->val.tval);
                goto out;
                break;
            default:
                return 0;
        }
        scan++;
    }
    return sum;
}

/*
 * Return Value: 0 - Failed or null. >0 - Number of writen characters.
 */
static unsigned int libdb_get_insert_statement(DBCOLUME **col_list, \
			    void *attr, void *buf, unsigned int length)
{
    if( col_list==NULL || attr==NULL || buf==NULL || !length )
	return 0;
    unsigned int sum = 0, n;
    DBCOLUME **scan = col_list;
    while( *scan!=NULL ) {
	switch( (*scan)->col_type ) {
	    case FLOAT:
		(*scan)->val.fval = *(float *)(attr + (*scan)->start_pos);
		if( (*scan)->val.fval==IGNORED )
		    break;
		n = snprintf(buf, length, "%f, ", (*scan)->val.fval);
out:            sum += n;
		length -= n;
		buf += n;
		break;
	    case DOUBLE:
		(*scan)->val.dval = *(double *)(attr + (*scan)->start_pos);
		if( (*scan)->val.dval==IGNORED )
		    break;
		n = snprintf(buf, length, "%lf, ", (*scan)->val.dval);
		goto out;
		break;
	    case CHAR:
	    case VARCHAR:
	    case NVARCHAR:
	    {
		unsigned int len = (*scan)->col_type_len;
		if( len==1 ) {
		    (*scan)->val.cval = *(char *)(attr + (*scan)->start_pos);
		    if( (*scan)->val.cval==IGNORED )
			break;
		}
		else {
		    (*scan)->val.buf = (char *)(attr + (*scan)->start_pos);
		    if( (*scan)->val.buf==NULL || !strlen((*scan)->val.buf) )
			break;
		}
		if( len==1 )
		    n = snprintf(buf, length, "'%c', ", (*scan)->val.cval);
		else
		    n = snprintf(buf, length, "'%s', ", (char *)((*scan)->val.buf));
		goto out;
		break;
	    }
	    case BIGINT:
		(*scan)->val.bval = *(bigint *)(attr + (*scan)->start_pos);
		if( (*scan)->val.bval==IGNORED )
		    break;
	    #ifdef __x86_64
		n = snprintf(buf, length, "%ld, ", (*scan)->val.bval);
	    #else
		n = snprintf(buf, length, "%lld, ", (*scan)->val.bval);
	    #endif
		goto out;
		break;
	    case INT:
		(*scan)->val.ival = *(int *)(attr + (*scan)->start_pos);
		if( (*scan)->val.ival==IGNORED )
		    break;
		n = snprintf(buf, length, "%d, ", (*scan)->val.ival);
		goto out;
		break;
	    case SMALLINT:
		(*scan)->val.sval = *(short *)(attr + (*scan)->start_pos);
		if( (*scan)->val.sval==IGNORED )
		    break;
		n = snprintf(buf, length, "%d, ", (*scan)->val.sval);
		goto out;
		break;
	    case TINYINT:
		(*scan)->val.sval = *(tinyint *)(attr + (*scan)->start_pos);
		if( (*scan)->val.tval==(tinyint)IGNORED )
		    break;
		n = snprintf(buf, length, "%d, ", (*scan)->val.tval);
		goto out;
		break;
	    default:
		return 0;
	}
	scan++;
    }
    return sum;
}

#endif

