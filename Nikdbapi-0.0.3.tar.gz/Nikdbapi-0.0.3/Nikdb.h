
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __MYDB
#define __MYDB
#define __MYSQL

#ifdef __MYSQL
#include<mysql.h>
#include<mysql_com.h>
#endif

#define MAX_HOST_LEN 64
#define MAX_USER_LEN 32
#define MAX_PASSWD_LEN 128
#define MAX_DBNAME_LEN 64
#define MAX_TBL_LEN 64
#define MAX_UNIX_SOCKET_LEN 128
#define MAX_QUERY_LEN 1024
#define MAX_COLUME_LEN 64
#define MAX_DATA_SIZE_LEN 32
#define MAX_OTHER_LEN 32

#define str(x) #x
/*data types*/
#define TINYBLOB 0
#define TINYTEXT 1
#define BLOB 2
#define TEXT 3
#define MEDIUMBLOB 4
#define MEDIUMTEXT 5
#define LONGBLOB 6
#define LONGTEXT 7
#define DATE 8
#define TIME 9
#define YEAR 10
#define DATETIME 11
#define TIMESTAMP 12
#define DECIMAL 13 /*unrecommend type*/
#define FLOAT 14	/*4*/
#define DOUBLE 15	/*8*/
#define CHAR 16		/*1*/
#define VARCHAR 17	/*1*/
#define NCHAR 18
#define NVARCHAR 19
#define BINARY 20
#define VARBINARY 21
#define BIGINT 22	/*8*/
#define INT 23		/*4*/
#define SMALLINT 24	/*2*/
#define TINYINT 25	/*1*/
#define BIT 26		/*unrecommend type*/

#define isNeedSize(x) ((x)>DOUBLE?1:0)
#define isAccuracy(x) (((x)==FLOAT || (x)==DOUBLE))
#define FLOATACC 2 /*Accuracy for float*/
#define DOUBLEACC 3 /*Accuracy for double*/
/*restrict marks*/
#define NOTNULL 0
#define DEFAULT 1
#define UNIQUE 2
#define CHECK 3
#define PRIMARYKEY 4
#define FORIGNKEY 5    /*MYSQL do not support this restrict*/
#define AUTOINCREMENT 6
#define Null 7

#define rStrict(x) (1<<(x))
/*query condition*/
#define NONE 0
#define EQUAL 1
#define GREATER 2
#define GEQUAL 3
#define LEQUAL 4
#define LESS 5
#define NEQUAL 6
#define LIKE 7
#define NOTLIKE 8
#define ISNULL 9
#define ISNOTNULL 10

typedef int integer;
typedef short smallint;
typedef unsigned char tinyint;
typedef unsigned char bit;
#ifdef __X86_64
typedef long bigint;
#else
typedef long long bigint;
#endif
typedef char varchar;

#ifdef __MYSQL
#define DATA_TYPE_STR_TBL_LEN 27
#define RESTRICT_STR_TBL 8
#define QUERY_CONDITION_LEN 11
#define TRANS_COLUME_LEN 4*MAX_COLUME_LEN
#define IGNORED (~0)
#define UPDATE 1
#define INSERT 0
typedef MYSQL DBDESC;
typedef MYSQL_RES DBRES;
typedef MYSQL_ROW DBROW;
typedef MYSQL_FIELD DBFIELD;
typedef unsigned int errno_t;
typedef struct { /*define for libdb_connect()*/
    DBDESC *desc;
    char host[MAX_HOST_LEN];
    char user[MAX_USER_LEN];
    char passwd[MAX_PASSWD_LEN];
    char *db;
    unsigned int port;
    char *unix_socket;
    unsigned long client_flag;
}connect_t;

typedef struct { /*define for libdb_shutdown()*/
    DBDESC *desc;
    unsigned char shutdown_level;
}shutdown_t;

/* DBCOLUME: In function libdb_relocate(),
 * rstrict will be used as the start position in BUF( which used in libdb_read_tbl(), etc).
 */ 
typedef struct {
    int col_type;
    char col_name[MAX_COLUME_LEN];
    unsigned int rstrict;
    int col_type_len;
    int start_pos;
    union {
        void *buf;
        float fval;
        double dval;
        char cval;
        bigint bval;
        int ival;
        short sval;
        tinyint tval;
        bit bitval;
    }val;
    unsigned int query_cond; /*query condition*/
}DBCOLUME;
/*declarations*/
/*Set log fp, can write to stderr or other log file.*/
void set_log_fp(FILE *fp);
/*Initialization. Can return a database descriptor.*/
void *libdb_init(DBDESC *desc);
/*Connect to DB server.*/
void *libdb_connect(void *param);
/*Close the connection which connected to DB server.*/
void libdb_close(DBDESC *desc);
/*Get the error number. Aim to mysql temporarily.*/
errno_t libdb_get_errno(DBDESC *desc);
/*Get the latest error message.*/
char *libdb_strerror(DBDESC *desc);
/*Shutdown the Database.*/
int libdb_shutdown(void *param);
/*Check the connection status. It may connect one more time, if it was broken.*/
int libdb_check_connection(DBDESC *desc);
/*Set current database.*/
int libdb_set_default_db(DBDESC *desc, const char *db);
/*Get the DB server state.*/
char *libdb_get_dbserver_stat(DBDESC *desc);
/*Create new database.*/
int libdb_create_db(DBDESC *desc, const char *dbname);
/*Drop a database.*/
int libdb_drop_db(DBDESC *desc, const char *dbname);
/*Same as command 'show databases'.*/
char **libdb_get_db_list(DBDESC *desc, int *num_row);
/*Free memory.*/
void libdb_clean_mem(char **list);
/*Create new table.*/
int libdb_create_tbl(DBDESC *desc, \
const char *tblname, DBCOLUME *col_list, int nr_col);
/*Drop a table.*/
int libdb_drop_tbl(DBDESC *desc, const char *tblname);
/*Add a Colume.*/
int libdb_add_col(DBDESC *desc, const char *tblname, DBCOLUME *col);
/*Delete a Colume.*/
int libdb_del_col(DBDESC *desc, \
const char *tblname, const char *colname);
/*Get all colume informations of the specific table.*/
DBCOLUME **libdb_get_col_info(DBDESC *desc, const char *tblname);
/*Add Primary key.*/
int libdb_add_primary_key(DBDESC *desc, \
const char *tbl_name, const char *col_name);
/*Delete Primary key.*/
int libdb_del_primary_key(DBDESC *desc, const char *tbl_name);
/*Change table name.*/
int libdb_chg_tbl_name(DBDESC *desc, \
const char *oldname, const char *newname);
/*Change the colume attribute.*/
int libdb_mod_col_info(DBDESC *desc, \
const char *tblname, DBCOLUME *oldcol, DBCOLUME *newcol);
/*Get the row number of table.*/
unsigned int libdb_get_nr_row(DBDESC *desc, \
DBCOLUME *col, const char *tblname);
/*Get whole table data with regular datatype.*/
int libdb_read_reg_tbl(DBDESC *desc, const char *tblname, \
            DBCOLUME *col, void *buf, unsigned int length);
/*Get one or more rows by colume attribute.*/
int libdb_read_reg_row(DBDESC *desc, const char *tblname, \
                void *attr, void *buf, unsigned int length);
/*Delete all data in specific table.*/
int libdb_del_reg_tbl(DBDESC *desc, const char *tblname, DBCOLUME *col);
/*Delete one or more data in specific table by attribute.*/
int libdb_del_reg_row(DBDESC *desc, const char *tblname, void *attr);
/*Update*/
int libdb_update_reg_row(DBDESC *desc, const char *tblname, void *attr, void *val);
/*Insert*/
int libdb_insert_reg_row(DBDESC *desc, \
const char *tblname, void *attr, unsigned int length);

/*extern global variables*/
extern unsigned int liberrno;
#endif

#endif
